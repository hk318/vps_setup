---
title: 免费出国留学
date: 2018-6-4
tags:  [shadowsocks]
---

蘭雅sRGB 龙芯小本服务器 [http://sRGB.vicp.net](http://srgb.vicp.net)

### 免费出国留学 1   [https://doub.io/sszhfx/]( https://doub.io/sszhfx/)

Windows 打开本地DNS文件：

	C:\Windows\System32\drivers\etc\hosts

在该文件最后追加一行：

	104.28.2.6 doub.io

- 然后访问https://doub.io，如果不行就清理浏览器缓存。
- 注意：必须通过 HTTPS 访问才行。



### 免费出国留学 2 [https://my.freess.today/](https://my.freess.today/)
- 这个网站电脑手机的软件都全了
- 通过扫描二维吗，获取临时服务器，不过安卓手机没Google play 好像不能扫描的
- 所以先安装 windows 的软件吧，哪个可以扫描识别二维码的


### 免费出国留学 3 [http://free-ss.cf/](http://free-ss.cf/)
